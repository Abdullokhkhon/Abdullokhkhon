matrix = [
    [-6, 6, -8],
    [6, -4, 9],
    [-8, 9, -2]
]

def transpose(array):
    s = len(array)
    for i in range(s - 1):
        for j in range(s):
            array[j][i], array[i][j] = array[i][j], array[j][i]
            s -=1
    return array


print(transpose(matrix))