#Эта программа строит исходный график.
import numpy as np
import matplotlib.pyplot as plt


X = [i for i in np.arange(-2, 2, 0.1)]
Y = []
Z = []
for i in X:
    Y.append(2**i+i**2-2)
    Z.append(0)
S = plt.plot(X, Y, label = 'Функция')
B = plt.plot(X, Z, label = 'Ось Х')
plt.legend()
plt.grid()
plt.savefig('graf1.png')